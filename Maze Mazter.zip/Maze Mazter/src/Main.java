import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.JFrame;

/**
 * 
 * @author Noah Burnette
 * @date 03/19/2021
 * @version 0.1.0
 *
 */
public class Main extends Canvas implements Runnable  {
	// gets device resolution
	static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	// constants
	public static final double WIDTHDBL = (int)screenSize.getWidth();
	public static final double HEIGHTDBL = (int)screenSize.getHeight();
	private static final long serialVersionUID = 1L;
	public static final int WIDTH = (int)WIDTHDBL;
	public static final int HEIGHT = (int)HEIGHTDBL;
	public static final int SCALE = 2;
	public static final String TITLE = "Maze Mazter";
	
	private boolean running = false;
	private Thread thread;
	
	private BufferedImage image = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);
	private BufferedImage spriteSheet = null;
	
	private BufferedImage player;
	
	public void init() {
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			
			spriteSheet = loader.loadImage("/enemy_knight.png");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		SpriteSheet ss = new SpriteSheet(spriteSheet);
		player = ss.grabImage(1, 1, 608, 608);
		
	}// init method
	
	private synchronized void start() {
		if(running) {
			return;
		}
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	private synchronized void stop() {
		if(!running) {
			return;
		}
		running = false;
		try {
			thread.join();
		}// try for stop method
		catch (InterruptedException e) {
			e.printStackTrace();
		} // catch for stop method
		System.exit(1);
	}// stop Method
	
	public void run() {
		init();
		long lastTime = System.nanoTime();
		final double AMOUNTOFTICKS = 60.0;
		double ns = 1000000000 / AMOUNTOFTICKS;
		double delta = 0;
		int updates = 0;
		int frames = 0;
		long timer = System.currentTimeMillis();
		
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			if(delta >= 1) {
				tick();
				updates ++;
				delta --;
			}// if delta >= 1
			render();
			frames ++;
			
			if(System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println(updates + " Ticks, fps " + frames);
				updates = 0;
				frames = 0;
			}
			
			
		}// running loop
		stop();
		
	}// run method
	private void tick() {
		
	}// tick method
	private void render() {
		
		BufferStrategy bs = this.getBufferStrategy(); 
		if(bs == null) {
			createBufferStrategy(3);
			return;
		}// if(bs == null)
		
		Graphics g = bs.getDrawGraphics();
		/////////////////////////////////
		
		g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
		
		g.drawImage(player, 0, 0, this);
		
		////////////////////////////////
		g.dispose();
		bs.show();
		
		
	}// render method

	public static void main(String[] args) {
		Main win = new Main();
		
		win.setPreferredSize(new Dimension(WIDTH * SCALE , HEIGHT * SCALE ));
		win.setMaximumSize(new Dimension(WIDTH * SCALE , HEIGHT * SCALE ));
		win.setMinimumSize(new Dimension(WIDTH * SCALE , HEIGHT * SCALE ));

		JFrame frame = new  JFrame (win.TITLE);
		
		frame.add(win);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		win.start();
	}// main method

}// Main class
