Hey!

Requirements to play this game:
	Python(IDLE)
	Pygame



To install pygame just type:
"python3 -m pip install -U pygame --user" into your console (command prompt)
Make sure you have python already installed too.

The two windows that should be open while playing the game are:
   The Pygame window that opens when the script is ran.
   
   The Python shell that is responsible for the input and interaction
   of the user

The best way to view the code is to use idle to view the code.

	Launch IDLE
	Open File
	Go to this folder 
	Open "Maze Mazter".py
	Run 
	Run module (F5)

Running the .py file without IDLE will not work because this game requires input 
through the shell.  