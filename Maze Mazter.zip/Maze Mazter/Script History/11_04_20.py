# Noah Burnette
# To install pygame just type:
# "python3 -m pip install -U pygame --user" into your console
# Make sure you have python already instead too.
# Next, import pygame as below.
import pygame
import time
import os 
# I use IDLE when I program small projects
# It does not really matter what you use as long as it works
#
# Turn Based Dungeon Crawler (Like the ones from the 70s/80s):
#   Something with basic graphics and very much 2d
#   The "RPG" element of the interaction is reliant on the shell.
#   Most of the game will be played in the shell.
#   Make a dungeon and enemy randomizer:
#       This will be fun to make but tedious
#   The graphics and window optimization will take the longest
#
# The two windows that should be open while playing the game are:
#   The Pygame window that opens when the shell is ran.
#   The Python shell that is responsible for the input and interaction
#   of the user
#
# Because of the time constraint, we won't use classes
# also, we haven't learned them yet.
#
# Intializing Pygame
pygame.init()
# Major variables will be stored (Here) 
display_width = 600
display_height = 600
black = (0,0,0)
game_display = pygame.display.set_mode(size = (display_width,display_height))
game_fill = game_display.fill(black)
caption = pygame.display.set_caption("Final Project")
# Functions 
#   Image translation
def img_fit(img):
    load_img = pygame.image.load(img)
    game_display.blit(load_img,(0,0))
    pygame.transform.scale(load_img,(600,600))
    pygame.display.update()
# Used this to test my game folder and the img_fit function:    
#   img_fit("IMG_2497.JPG")
#   time.sleep(1)
#   time.sleep(1)
#   img_fit("ice.JPG")
#
# Character Creation(Here) inputs:
#   I plan to use attribute points so we will need loops as well(Here)
#
#Randomizers that will be created(Here):
#   Encounters, Locations, Chance to hit(Based off attributes above^)
#
# The Running loop... Very Important 
Running = True
while Running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False
            pygame.display.quit()
            pygame.quit()
            quit()
      
    
    

