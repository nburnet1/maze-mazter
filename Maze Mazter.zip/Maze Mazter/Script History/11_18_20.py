# Noah Burnette
# To install pygame just type:
# "python3 -m pip install -U pygame --user" into your console
# Make sure you have python already instead too.
# Next, import pygame as below.
import pygame
import time
import os
import random
# I use IDLE when I program small projects
# It does not really matter what you use as long as it works
#
# Turn Based Dungeon Crawler (Like the ones from the 70s/80s):
#   Something with basic graphics and very much 2d
#   The "RPG" element of the interaction is reliant on the shell.
#   Most of the game will be played in the shell.
#   Make a dungeon and enemy randomizer:
#       This will be fun to make but tedious
#   The graphics and window optimization will take the longest
#
# The two windows that should be open while playing the game are:
#   The Pygame window that opens when the shell is ran.
#   The Python shell that is responsible for the input and interaction
#   of the user
#
# Because of the time constraint, we won't use classes
# also, we haven't learned them yet.
#
# Intializing Pygame
pygame.init()
# Major variables will be stored (Here) 
display_width = 600
display_height = 600
black = (0,0,0)
# Picture paths as variables or in character's list:
#   test = "Pictures/test.png"
# Functions 
#   Image translation
#       Arguments:
#           The file location of the image
def img_fit(img):
    load_img = pygame.image.load(img)
    game_display.blit(load_img,(0,0))
    pygame.transform.scale(load_img,(600,600))
    pygame.display.update()
# Character Creation
#   Character list:
#       Name
#       Strength
#       Agility
#       Luck
#       Trade
#       Instinct
char_list = []
char_name = input("What is your name?\n")
char_str = 0
char_agl = 0
char_luck = 0
char_trade = 0
char_instinct = 0
char_list.append(char_name)
total_attrib_points = random.randrange(10,15)
attrib_points_used = 0
# Loop to ensure the attributes cannot be exploited
while True:
    print("You have",total_attrib_points,"attribute points to use\n\n")
    char_str = int(input("How strong are you?\n"))
    char_agl = int(input("How agile are you?\n"))
    char_luck = int(input("How lucky are you?\n"))
    char_trade = int(input("How charasmatic are you?\n"))
    char_instinct = int(input("How instinctual are you?\n"))
    attrib_points_used = char_str + char_agl + char_luck + char_trade + char_instinct
    if attrib_points_used == total_attrib_points:
        char_list.append(char_str)
        char_list.append(char_agl)
        char_list.append(char_luck)
        char_list.append(char_trade)
        char_list.append(char_instinct)
        break
    else:
        attrib_points_used = 0 
# NPC traits = [Name,image path, str, agl, luck, trade, instinct]
enemy_rat = ["Rat","Pictures/enemy_rat.png",2,3,1,0,0]
enemy_knight = ["Knight","Pictures/enemy_knight.png",4,2,2,2,1]
trainer_agl = ["Trainer(Agility)","Pictures/trainer_agl.png",0,0,0,6,5]
# Randomizers that will be created(Here):
#   Encounters, Locations, Chance to hit(Based off attributes above^)
rand_encounter_list  = [enemy_rat,enemy_knight,trainer_agl]
# Intitializing the window
game_display = pygame.display.set_mode(size = (display_width,display_height))
game_fill = game_display.fill(black)
caption = pygame.display.set_caption("Maze Crawler")
pygame.display.update()
# The Running loop... Very Important 
Running = True
Interaction = False
Combat = False
arb_npc = []
while Running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False
            pygame.display.quit()
            pygame.quit()
            quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP or event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                arb_npc = rand_encounter_list[random.randrange(0,len(rand_encounter_list))]
                img_fit(arb_npc[1])
                Interaction = True
            if event.key == pygame.K_DOWN:
                print("Only cowards go back...")
    while Interaction:
        if char_list[5] > arb_npc[6]:
            print("You have encountered a",arb_npc[0])
        else:
            print("You have encountered an unknown being")
        Interaction = False
      
    
    

